node r.js -o demo/app.build.js
node r.js -o cssIn=demo-build/styles/screen.build.css out=demo-build/styles/screen.build.css
